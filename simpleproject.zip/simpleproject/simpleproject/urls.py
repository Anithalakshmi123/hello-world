from django.urls import path

from people.views import PersonHomeView, PersonListView, PersonCreateView, PersonUpdateView


urlpatterns = [
    path('',PersonHomeView.as_view(), name='home'),
    path('list/', PersonListView.as_view(), name='person_list'),
    path('add/', PersonCreateView.as_view(), name='person_add'),
    path('<int:pk>/edit/', PersonUpdateView.as_view(), name='person_edit'),
    
    
]
